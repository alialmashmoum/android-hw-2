package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView a = findViewById(R.id.aassdd);
       final EditText N = findViewById(R.id.editTextTextPersonName);
        final  EditText D = findViewById(R.id.editTextTextPersonName2);
        final EditText F = findViewById(R.id.editTextTextPersonName3);
        final  EditText G= findViewById(R.id.editTextTextPersonName4);
        Button H = findViewById(R.id.button);
     H.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {

             int N1 = Integer.parseInt(N.getText().toString());
             int D2 = Integer.parseInt(D.getText().toString());
             int F3 = Integer.parseInt(F.getText().toString());
             int G4 = Integer.parseInt(G.getText().toString());
int booo = N1 + D2 + F3 + G4;
             Toast.makeText(MainActivity.this, booo + "", Toast.LENGTH_SHORT).show();
         }
     });
    }

}